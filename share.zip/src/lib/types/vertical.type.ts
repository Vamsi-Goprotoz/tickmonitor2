export interface Vertical {
  id: string;
  name: string;
}