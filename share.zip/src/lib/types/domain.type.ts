export interface Domain {
  domainName: string;
  domainId: string;
  domainUrl: string;
  details: any;
  id: string;
}
