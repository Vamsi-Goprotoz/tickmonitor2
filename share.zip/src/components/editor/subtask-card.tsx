export interface SubtaskCardInterface {
  title: string;
  id: string;
  description: string;
  startDate: Date;
  endDate: Date;
}

const SubtaskCard = ({}: SubtaskCardInterface) => {
  return <div>
    
  </div>;
};

export default SubtaskCard;
